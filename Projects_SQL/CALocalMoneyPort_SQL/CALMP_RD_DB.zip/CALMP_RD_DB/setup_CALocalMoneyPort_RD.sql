USE EXCHANGE

GO

INSERT INTO parametros VALUES('SACC','RUTAAPPENVIOID','\\gisrvrd\ejecutables\caja\IID\CALocalMoneyPort\CALocalMoneyPort.exe','Ruta donde apunta la aplicaci�n CALocalMoneyPort')
INSERT INTO parametros VALUES('SACC','RUTAAPPENVIOIU','\\gisrvrd\ejecutables\caja\IID\CALocalMoneyPort\CALocalMoneyPort.exe','Ruta donde apunta la aplicaci�n CALocalMoneyPort')
INSERT INTO parametros VALUES('SACC','RUTAAPPENVIOOI','\\gisrvrd\ejecutables\caja\IID\CALocalMoneyPort\CALocalMoneyPort.exe','Ruta donde apunta la aplicaci�n CALocalMoneyPort')
INSERT INTO parametros VALUES('SACC','RUTAAPPENVIORY','\\gisrvrd\ejecutables\caja\IID\CALocalMoneyPort\CALocalMoneyPort.exe','Ruta donde apunta la aplicaci�n CALocalMoneyPort')
INSERT INTO parametros VALUES('SACC','RUTARECIVOSEECAJA','\\gisrvrd\ejecutables\caja\IID\CALocalMoneyPort\CALocalMoneyPort.exe','Ruta donde apunta la aplicaci�n CALocalMoneyPort')

INSERT INTO parametros VALUES('SACC','APPENVIOID','ACTIVADO','(ACTIVADO/DESACTIVADO) Seran sus valores, APP que permite la busqueda de clave en Italtransfer')
INSERT INTO parametros VALUES('SACC','APPENVIOIU','ACTIVADO','(ACTIVADO/DESACTIVADO) Seran sus valores, APP que permite la busqueda de clave en Italcambio Internacional')
INSERT INTO parametros VALUES('SACC','APPENVIOOI','ACTIVADO','(ACTIVADO/DESACTIVADO) Seran sus valores, APP que permite la busqueda de clave en Italcambio')
INSERT INTO parametros VALUES('SACC','APPENVIORY','ACTIVADO','(ACTIVADO/DESACTIVADO) Seran sus valores, APP que permite la busqueda de clave en RAH')
INSERT INTO parametros VALUES('SACC','APPENVIOTS','ACTIVADO','(ACTIVADO/DESACTIVADO) Seran sus valores, APP que permite la busqueda de clave en Transfast')

